# save as weather_dashboard_advanced.py
import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import shap 

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from imblearn.combine import SMOTEENN
import lightgbm as lgb

st.set_page_config(page_title="Advanced Weather Dashboard", layout="wide")
st.title("🌦 Advanced Weather Dashboard & Prediction")

# ----------------------
# 1️⃣ Load Data
# ----------------------
@st.cache_data
def load_data():
    df = pd.read_csv("weather_data.csv", parse_dates=['Date'])
    df['Month'] = df['Date'].dt.month
    df['Day'] = df['Date'].dt.day
    df['DayOfWeek'] = df['Date'].dt.dayofweek
    df['IsWeekend'] = df['DayOfWeek'].apply(lambda x:1 if x>=5 else 0)
    
    # Season
    df['Season'] = df['Month'].apply(lambda m: 'Winter' if m in [12,1,2] else 
                                                 'Spring' if m in [3,4,5] else 
                                                 'Summer' if m in [6,7,8] else 'Autumn')
    
    # Lag features
    for lag in range(1,4):
        for col in ['Temperature_C','Humidity_%','WindSpeed_kmh']:
            df[f'{col}_lag{lag}'] = df[col].shift(lag)
    
    # Rolling features
    for col in ['Temperature_C','Humidity_%','WindSpeed_kmh']:
        df[f'{col}_roll3'] = df[col].rolling(3).mean()
        df[f'{col}_roll3_std'] = df[col].rolling(3).std()
    
    # Interaction features
    df['Temp_Humidity'] = df['Temperature_C']*df['Humidity_%']
    df['Wind_Precip'] = df['WindSpeed_kmh']*df['Precipitation_mm']
    
    # Cyclical encoding
    df['Month_sin'] = np.sin(2*np.pi*df['Month']/12)
    df['Month_cos'] = np.cos(2*np.pi*df['Month']/12)
    df['Day_sin'] = np.sin(2*np.pi*df['Day']/31)
    df['Day_cos'] = np.cos(2*np.pi*df['Day']/31)
    
    df = df.dropna().reset_index(drop=True)
    return df

df = load_data()

st.subheader("Raw Data Sample")
st.dataframe(df.head())

# ----------------------
# 2️⃣ Feature Selection
# ----------------------
feature_cols = [col for col in df.columns if col not in ['Date','WeatherType_encoded','Season']]
X = df[feature_cols]
y = df['WeatherType_encoded']

# ----------------------
# 3️⃣ Train/Test Split + Scaling + SMOTEENN
# ----------------------
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, stratify=y, random_state=42)

scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

smote_enn = SMOTEENN(random_state=42)
X_res, y_res = smote_enn.fit_resample(X_train_scaled, y_train)

# ----------------------
# 4️⃣ Train LightGBM
# ----------------------
lgb_clf = lgb.LGBMClassifier(random_state=42)
lgb_clf.fit(X_res, y_res)

# ----------------------
# 5️⃣ SHAP Explainer
# ----------------------
explainer = shap.Explainer(lgb_clf)
shap_values = explainer(X_test_scaled)

# ----------------------
# 6️⃣ Prediction UI
# ----------------------
st.subheader("Predict Weather Type")
with st.form("prediction_form"):
    temp = st.number_input("Temperature (C)", float(df['Temperature_C'].min()), float(df['Temperature_C'].max()), 25.0)
    humidity = st.number_input("Humidity (%)", int(df['Humidity_%'].min()), int(df['Humidity_%'].max()), 60)
    wind = st.number_input("WindSpeed (km/h)", int(df['WindSpeed_kmh'].min()), int(df['WindSpeed_kmh'].max()), 10)
    precip = st.number_input("Precipitation (mm)", int(df['Precipitation_mm'].min()), int(df['Precipitation_mm'].max()), 0)
    pressure = st.number_input("Pressure (hPa)", int(df['Pressure_hPa'].min()), int(df['Pressure_hPa'].max()), 1013)
    cloud = st.number_input("Cloud Cover (%)", int(df['CloudCover_%'].min()), int(df['CloudCover_%'].max()), 50)
    visibility = st.number_input("Visibility (km)", int(df['Visibility_km'].min()), int(df['Visibility_km'].max()), 10)
    is_weekend = st.selectbox("Is Weekend?", [0,1])
    
    submit_btn = st.form_submit_button("Predict")

if submit_btn:
    # Prepare features for input
    input_dict = {'Temperature_C': temp, 'Humidity_%': humidity, 'WindSpeed_kmh': wind,
                  'Precipitation_mm': precip,'Pressure_hPa': pressure,'CloudCover_%': cloud,
                  'Visibility_km': visibility,'IsWeekend': is_weekend,
                  'Temperature_C_lag1': temp,'Temperature_C_lag2': temp,'Temperature_C_lag3': temp,
                  'Humidity_%_lag1': humidity,'Humidity_%_lag2': humidity,'Humidity_%_lag3': humidity,
                  'WindSpeed_kmh_lag1': wind,'WindSpeed_kmh_lag2': wind,'WindSpeed_kmh_lag3': wind,
                  'Temperature_C_roll3': temp,'Temperature_C_roll3_std': 0,
                  'Humidity_%_roll3': humidity,'Humidity_%_roll3_std':0,
                  'WindSpeed_kmh_roll3': wind,'WindSpeed_kmh_roll3_std':0,
                  'Temp_Humidity': temp*humidity,'Wind_Precip': wind*precip,
                  'Month_sin': np.sin(2*np.pi*df['Month'].mean()/12),
                  'Month_cos': np.cos(2*np.pi*df['Month'].mean()/12),
                  'Day_sin': np.sin(2*np.pi*df['Day'].mean()/31),
                  'Day_cos': np.cos(2*np.pi*df['Day'].mean()/31)}
    
    input_df = pd.DataFrame([input_dict])[feature_cols]
    pred_proba = lgb_clf.predict_proba(input_df)[0]
    pred_class = np.argmax(pred_proba)
    
    weather_dict = {0:"Cloudy",1:"Rainy",2:"Sunny"}
    st.success(f"Predicted Weather Type: {weather_dict[pred_class]}")
    
    # Show probabilities
    prob_df = pd.DataFrame({'WeatherType': [weather_dict[i] for i in range(len(pred_proba))],
                            'Probability': pred_proba})
    st.write(prob_df)
    
    # SHAP explanation
    st.subheader("SHAP Feature Importance for this Prediction")
    shap_values_input = explainer(input_df)
    shap.plots.waterfall(shap_values_input[0])
    st.pyplot(bbox_inches='tight')
    
# ----------------------
# 7️⃣ Visualizations
# ----------------------
st.subheader("Exploratory Visualizations")
st.write("Temperature Distribution")
sns.histplot(df['Temperature_C'], bins=20,kde=True)
st.pyplot(plt)

st.write("Humidity Distribution")
sns.histplot(df['Humidity_%'], bins=20,kde=True)
st.pyplot(plt)

st.write("Season vs Temperature")
sns.boxplot(x='Season',y='Temperature_C',data=df)
st.pyplot(plt)

st.write("Temp*Humidity vs Precipitation")
sns.scatterplot(x='Temp_Humidity',y='Precipitation_mm',hue='WeatherType_encoded',data=df)
st.pyplot(plt) 
