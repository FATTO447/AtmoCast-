
### Make sure to create a `.env` file with following variables -and assign value of apikey from openweather site

```
VITE_OPENWEATHER_API_KEY=
```
###install nodemoduls
```
npm install
```
###Add Tailwind CSS
```
npm install tailwindcss @tailwindcss/vite
```

###run code
```
npm run dev
```



