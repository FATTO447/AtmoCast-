package com.weather_appDemo.wheatherApp.model;

public class WeatheResponse {
}
