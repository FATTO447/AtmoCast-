package com.weather_appDemo.wheatherApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WheatherAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(WheatherAppApplication.class, args);
	}

}
