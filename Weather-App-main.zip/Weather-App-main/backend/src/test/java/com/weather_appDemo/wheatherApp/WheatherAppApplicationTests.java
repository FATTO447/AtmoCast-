package com.weather_appDemo.wheatherApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WheatherAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
